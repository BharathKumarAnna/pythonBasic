import os
from flask import Flask, request, render_template, redirect, url_for
from werkzeug.utils import secure_filename
import pdfplumber
from docx import Document
import re
import nltk
import openpyxl

nltk.download('punkt_tab')

# Define Flask app
app = Flask(__name__)

# Configure upload folder
UPLOAD_FOLDER = 'uploads'
ALLOWED_EXTENSIONS = {'txt', 'pdf', 'docx'}
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

# Predefined skill set
SKILL_SET = {"Python", "Java", "C++", "JavaScript", "SQL", "Machine Learning", "Data Analysis","NodeJs","ExpressJs","Html","css"}

def allowed_file(filename):
    """Check if the uploaded file has an allowed extension."""
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

def extract_text(file_path):
    """Extract text from TXT, PDF, or DOCX files."""
    if file_path.endswith('.txt'):
        with open(file_path, 'r', encoding='utf-8') as f:
            return f.read()
    elif file_path.endswith('.pdf'):
        text = ""
        with pdfplumber.open(file_path) as pdf:
            for page in pdf.pages:
                text += page.extract_text() or ""
        return text
    elif file_path.endswith('.docx'):
        doc = Document(file_path)
        return "\n".join([para.text for para in doc.paragraphs])
    else:
        return ""
    
# def extract_information(text):
#     """Extract name, email, phone, and skills from the text."""
#     # Split the text into lines for extracting details from the first 3 lines
#     lines = text.splitlines()[:3]

#     # Regex patterns
#     email_pattern = r"([a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,})"
#     phone_pattern = r"\+?\d{10,15}"

#     # Extract information from the first 3 lines
#     name = lines[0].strip() if len(lines) > 0 else "Not Found"
#     email = next((re.search(email_pattern, line).group(0) for line in lines if re.search(email_pattern, line)), "Not Found")
#     phone = next((re.search(phone_pattern, line).group(0) for line in lines if re.search(phone_pattern, line)), "Not Found")

#     # Extract skills from the entire text
#     skills = extract_skills(text, SKILL_SET)

#     return {
#         'name': name.strip(),
#         'email': email,
#         'phone': phone,
#         'skills': ", ".join(skills),
#     }
# def extract_information(text):
#     """Extract name, email, phone, and skills from the text."""
#     # Email regex
#     email_pattern = r"([a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,})"
#     # Phone regex
#     phone_pattern = r"\+?\d{10,15}"
#     # Simple name heuristic: Assuming name appears in the first 50 characters
#     # lines = text.split("\n")
#     # name = lines[0].strip() if len(lines[0]) < 50 else "Not Found"

#     email = re.findall(email_pattern, text)
#     phone = re.findall(phone_pattern, text)
#     skills = extract_skills(text, SKILL_SET)

#     return {
#         # 'name': name,
#         'email': email[0] if email else "Not Found",
#         'phone': phone[0] if phone else "Not Found",
#         'skills': ", ".join(skills),
#     }

def extract_skills(text, skill_set):
    """Extract skills from the given text."""
    words = nltk.word_tokenize(text.lower())
    return set(skill for skill in skill_set if skill.lower() in words)

def process_resumes(folder):
    """Process all resumes in the upload folder and extract skills."""
    resumes = []
    for filename in os.listdir(folder):
        file_path = os.path.join(folder, filename)
        text = extract_text(file_path)
        if text:  # Ensure valid text was extracted
            skills = extract_skills(text, SKILL_SET)
            resumes.append({'filename': filename, 'skills': list(skills)})
    return sorted(resumes, key=lambda x: len(x['skills']), reverse=True)

# def save_to_excel(data, output_file='resumes_data.xlsx'):
#     """Save extracted resume data to an Excel file."""
#     wb = openpyxl.Workbook()
#     ws = wb.active
#     ws.title = "Resumes Data"

#     # Add headers
#     ws.append(["Email", "Phone", "Skills"])

#     # Add data rows
#     for entry in data:
#         ws.append([entry['email'], entry['phone'], entry['skills']])

#     wb.save(output_file)

# def save_to_excel(data, output_file='resumes_data.xlsx'):
#     """Save extracted resume data to an Excel file."""
#     wb = openpyxl.Workbook()
#     ws = wb.active
#     ws.title = "Resumes Data"

#     # Add headers
#     ws.append(["Name", "Email", "Phone", "Skills"])

#     # Add data rows
#     for entry in data:
#         ws.append([entry['name'], entry['email'], entry['phone'], entry['skills']])

#     wb.save(output_file)

@app.route('/', methods=['GET', 'POST'])
def index():
    if request.method == 'POST':
        # Handle file uploads
        if 'resumes' not in request.files:
            return redirect(request.url)
        files = request.files.getlist('resumes')
        for file in files:
            if file and allowed_file(file.filename):
                filename = secure_filename(file.filename)
                file.save(os.path.join(app.config['UPLOAD_FOLDER'], filename))
        return redirect(url_for('results'))

    return render_template('index.html')

@app.route('/results', methods=['GET'])
def results():
    resumes = process_resumes(app.config['UPLOAD_FOLDER'])
    # save_to_excel(resumes)
    return render_template('results.html', resumes=resumes)

if __name__ == '__main__':
    app.run(debug=True)
