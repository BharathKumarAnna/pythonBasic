import os
import re
import pdfplumber
from docx import Document
import openpyxl

# Set the directory containing resumes
RESUME_DIR = "uploads"  # Replace with your folder path
OUTPUT_FILE = "extracted_data.xlsx"

# Regular expressions for email and phone number
EMAIL_REGEX = r"[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}"
PHONE_REGEX = r"\+?\d{10,15}"

def extract_text_from_pdf(file_path):
    """Extract text from a PDF file."""
    text = ""
    with pdfplumber.open(file_path) as pdf:
        for page in pdf.pages:
            text += page.extract_text() or ""
    return text

def extract_text_from_docx(file_path):
    """Extract text from a DOCX file."""
    doc = Document(file_path)
    return "\n".join([para.text for para in doc.paragraphs])

def extract_text_from_txt(file_path):
    """Extract text from a TXT file."""
    with open(file_path, 'r', encoding='utf-8') as file:
        return file.read()

def extract_data(text):
    """Extract emails and phone numbers from text."""
    emails = re.findall(EMAIL_REGEX, text)
    phones = re.findall(PHONE_REGEX, text)
    return {
        "email": emails[0] if emails else "Not Found",
        "phone": phones[0] if phones else "Not Found",
    }

def process_resumes(resume_dir):
    """Process all resumes in the given directory."""
    extracted_data = []

    for filename in os.listdir(resume_dir):
        file_path = os.path.join(resume_dir, filename)
        file_extension = filename.split('.')[-1].lower()

        # Extract text based on file type
        if file_extension == "pdf":
            text = extract_text_from_pdf(file_path)
        elif file_extension == "docx":
            text = extract_text_from_docx(file_path)
        elif file_extension == "txt":
            text = extract_text_from_txt(file_path)
        else:
            print(f"Unsupported file format: {filename}")
            continue

        # Extract emails and phone numbers
        data = extract_data(text)
        data["filename"] = filename
        extracted_data.append(data)

    return extracted_data

def save_to_excel(data, output_file):
    """Save extracted data to an Excel file."""
    workbook = openpyxl.Workbook()
    sheet = workbook.active
    sheet.title = "Resume Data"

    # Add headers
    sheet.append(["Filename", "Email", "Phone"])

    # Add data rows
    for entry in data:
        sheet.append([entry["filename"], entry["email"], entry["phone"]])

    workbook.save(output_file)

def main():
    # Process resumes and save data
    data = process_resumes(RESUME_DIR)
    save_to_excel(data, OUTPUT_FILE)
    print(f"Data successfully saved to {OUTPUT_FILE}")

if __name__ == "__main__":
    main()
